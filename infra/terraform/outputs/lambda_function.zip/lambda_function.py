import boto3
import json

ses_client = boto3.client('ses', region_name='us-east-1')

def lambda_handler(event, context):
    for record in event['Records']:
        mensagem_str = record['Sns']['Message']
        dados = json.loads(mensagem_str)

        email_cliente = dados.get('email_cliente')
        nome          = dados.get('nome_cliente', 'Cliente')
        status        = dados.get('status', 'PENDING')
        id_pedido     = dados.get('id_pedido', 'N/A')

        if status == "ACCEPTED":
            assunto = "🎉 Seu pedido foi aceito!"
            corpo = f"Ola {nome},\n\nSeu pedido {id_pedido} foi processado e ACEITO com sucesso!"
        else:
            assunto = "⚠️ Problema com seu pedido"
            corpo = f"Ola {nome},\n\nHouve um problema. Seu pedido {id_pedido} nao foi aceito."

        try:
            ses_client.send_email(
                Source='helio.fagundes.dev@gmail.com',
                Destination={'ToAddresses': [email_cliente]},
                Message={
                    'Subject': {'Data': assunto},
                    'Body': {'Text': {'Data': corpo}}
                }
            )
            print(f"E-mail enviado com sucesso para {email_cliente}")
        except Exception as e:
            print(f"Erro ao enviar e-mail: {str(e)}")
